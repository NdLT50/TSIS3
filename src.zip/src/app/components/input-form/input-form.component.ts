import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-input-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <form [formGroup]="costForm" (ngSubmit)="onSubmit()" class="form-grid">
      <label>Model 
        <select formControlName="model">
          <option value="flash">Gemini 1.5 Flash</option>
          <option value="pro">Gemini 1.5 Pro</option>
        </select>
      </label>

      <label>Monthly Users 
        <input type="number" formControlName="monthlyUsers" placeholder="e.g. 1000">
      </label>

      <label>Messages per User 
        <input type="number" formControlName="messagesPerUser">
      </label>

      <label>Avg Input Tokens 
        <input type="number" formControlName="avgInputTokens">
      </label>

      <label>Avg Output Tokens 
        <input type="number" formControlName="avgOutputTokens">
      </label>

      <label>Function Invocations 
        <input type="number" formControlName="invocations">
      </label>

      <label>Execution Time (ms) 
        <input type="number" formControlName="executionTimeMs">
      </label>

      <label>Memory (MB) 
        <input type="number" formControlName="memoryMb">
      </label>

      <label>DB Storage (GB) 
        <input type="number" formControlName="dbStorageGb">
      </label>

      <label>Document Writes 
        <input type="number" formControlName="documentWrites">
      </label>

      <label>Cloud Storage (GB) 
        <input type="number" formControlName="cloudStorageGb">
      </label>

      <button type="submit" [disabled]="costForm.invalid">
        Calculate Monthly Cost
      </button>
    </form>
  `
})
export class InputFormComponent {
  @Output() calculate = new EventEmitter<any>();
  costForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.costForm = this.fb.group({
      model: ['flash'],
      monthlyUsers: [0, [Validators.required, Validators.min(0)]],
      messagesPerUser: [0, [Validators.required, Validators.min(0)]],
      avgInputTokens: [0, [Validators.required, Validators.min(0)]],
      avgOutputTokens: [0, [Validators.required, Validators.min(0)]],
      invocations: [0, [Validators.required, Validators.min(0)]],
      executionTimeMs: [0, [Validators.required, Validators.min(0)]],
      memoryMb: [128, [Validators.required, Validators.min(128)]],
      dbStorageGb: [0, [Validators.required, Validators.min(0)]],
      documentWrites: [0, [Validators.required, Validators.min(0)]],
      cloudStorageGb: [0, [Validators.required, Validators.min(0)]]
    });
  }

  onSubmit() {
    if (this.costForm.valid) {
      this.calculate.emit(this.costForm.value);
    }
  }
}
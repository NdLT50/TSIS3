import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-results-panel',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="results-card" *ngIf="results">
      <div class="result-row">
        <span>Compute Cost (Functions)</span>
        <strong>{{ results.computeCost | currency:'USD':'symbol':'1.2-4' }}</strong>
      </div>
      
      <div class="result-row">
        <span>LLM Inference (Gemini)</span>
        <strong>{{ results.llmCost | currency }}</strong>
      </div>
      
      <div class="result-row">
        <span>Database (Firestore)</span>
        <strong>{{ results.firestoreCost | currency }}</strong>
      </div>
      
      <div class="result-row">
        <span>Cloud Storage</span>
        <strong>{{ results.storageCost | currency }}</strong>
      </div>
      
      <div class="total-row">
        <span>Estimated Total</span>
        <span>{{ results.totalCost | currency }}</span>
      </div>
    </div>
  `
})
export class ResultsPanelComponent {
  @Input() results: any;
}
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputFormComponent } from '../input-form/input-form.component';
import { ResultsPanelComponent } from '../results-panel/results-panel.component';
import { PricingEngineService } from '../../services/pricing-engine.service';

@Component({
  selector: 'app-chat-shell',
  standalone: true,
  imports: [CommonModule, InputFormComponent, ResultsPanelComponent],
  template: `
    <div style="max-width: 500px; margin: auto; padding: 20px; border: 1px solid #eee;">
      <h1>CFO Bot Calculator</h1>
      <app-input-form (calculate)="onCalculate($event)"></app-input-form>
      <app-results-panel [results]="results"></app-results-panel>
    </div>
  `
})
export class ChatShellComponent {
  results: any;
  constructor(private engine: PricingEngineService) {}

  onCalculate(data: any) {
    this.results = this.engine.calculate(data);
  }
}